#include <iostream>
#include "TileMoney.h"
#include "Player.h"
#include "Tile.h"
#include "TilePoints.h"

using namespace std;

TilePoints::TilePoints(unsigned int points1) : Tile()
{
	//set the member variable.
	pointsReceive = points1;
}

TilePoints::TilePoints(const TilePoints& to_copy) : Tile(to_copy)
{
	//set the member variable.
	pointsReceive = to_copy.pointsReceive;
}

TilePoints :: ~TilePoints()
{
	// It should be empty.
}

TilePoints& TilePoints :: operator= (const TilePoints& to_copy)
{
	if (this != &to_copy)
	{
		pointsReceive = to_copy.pointsReceive;
	}
	return *this;
}

Tile* TilePoints::getClone() const
{
	Tile* copy = new TilePoints(*this);

	return copy;
}

void TilePoints::activate(unsigned int who_rolled, const CellId& cell, Board& board) const
{
	unsigned int player = getAffectedPlayer(who_rolled);

	playerIncreasePointsAndPrint(player, pointsReceive);
}

void TilePoints::print() const
{
	//call the printOwnerChar function.
	printOwnerChar();

	//print Genus Char
	cout << "*";

	//print Species Char
	cout << pointsReceive;

}