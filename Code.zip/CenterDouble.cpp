#include <iostream>
#include <string>
#include <sstream>
#include "CenterDouble.h"
using namespace std;

string centerDouble(double value)
{
	return centerDouble(value, 79);
}

string centerDouble(double value, unsigned int width)
{
	stringstream ss;
	ss << value;

	string str = "";
	str = ss.str();

	unsigned int size = width - str.length();

	if (str.length() >= width)
	{
		return str;
	}
	else
	{
		for (int i = 0; i < size; i++)
		{
			if (i % 2 == 0)
			{
				str = " " + str;
			}
			else
			{
				str = str + " ";
			}
		}
		return str;
	}

}