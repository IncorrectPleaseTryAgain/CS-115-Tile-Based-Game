template <typename Data>
string center(const Data& value);

template <typename Data>
string center(const Data& value,unsigned int width);

#include "Center.inl"