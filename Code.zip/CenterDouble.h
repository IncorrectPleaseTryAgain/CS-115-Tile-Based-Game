
#pragma once
#include <string>
using namespace std;

string centerDouble(double value);

string centerDouble(double value,unsigned int width);