//
//  TestCenter6.cpp
//
//  A test program for the CenterDouble and Center modules.
//    This program includes all the tests from
//    TestCenterDouble6.
//
//  This program is to be used with Assignment 6: Part F of
//    CS115, 202110.
//
//  Do not modify this file.
//

#include "CenterDouble.h"
#include "CenterDouble.h"  // repeated to test for #include errors
#include "Center.h"
#include "Center.h"  // repeated to test for #include errors

#include <cassert>
#include <cmath>
#include <string>
#include <iostream>
#include <sstream>

#include "TestHelper.h"

using namespace std;

const int COMPILE_AND_START_MARKS = 3;
const int DID_NOT_CRASH_RUNNING_MARKS = 3;
const int COMPILE_AND_NOT_CRASH_MARKS = COMPILE_AND_START_MARKS + DID_NOT_CRASH_RUNNING_MARKS;
const int COMBINED_TEST_MARKS = 9;
const int TOTAL_MARKS = COMPILE_AND_NOT_CRASH_MARKS + COMBINED_TEST_MARKS;

const unsigned int CORRECT_WIDTH_FULL_CENTER = 79;

const unsigned int TEST_VALUE_COUNT = 5;
const unsigned int CHECKS_PER_BLOCK_VALUE = 5;
const unsigned int BLOCK_TYPE_COUNT = 4;

const unsigned int CHECKS_PER_BLOCK = CHECKS_PER_BLOCK_VALUE * TEST_VALUE_COUNT;
const unsigned int CHECKS_PER_TEST_TYPE = BLOCK_TYPE_COUNT       * TEST_VALUE_COUNT;



class CenterResultsBlock
{
public:
	CenterResultsBlock();
	int getSum() const;
	CenterResultsBlock& operator+= (const CenterResultsBlock& rhs);

public:
	int long_enough;
	int short_enough;
	int contains_original;
	int equal_padding;
	int padded_with_spaces;
};

CenterResultsBlock::CenterResultsBlock()
	: long_enough(0),
	short_enough(0),
	contains_original(0),
	equal_padding(0),
	padded_with_spaces(0)
{ }

int CenterResultsBlock::getSum() const
{
	return long_enough +
		short_enough +
		contains_original +
		equal_padding +
		padded_with_spaces;
}

CenterResultsBlock& CenterResultsBlock :: operator+= (const CenterResultsBlock& rhs)
{
	long_enough += rhs.long_enough;
	short_enough += rhs.short_enough;
	contains_original += rhs.contains_original;
	equal_padding += rhs.equal_padding;
	padded_with_spaces += rhs.padded_with_spaces;

	return *this;
}

struct CenterResultsDatatype
{
	CenterResultsBlock full_page;
	CenterResultsBlock box30;
	CenterResultsBlock box5;
	CenterResultsBlock columns;
};

struct CenterTotals
{
	int across_full_page;
	int across_box30;
	int across_box5;
	int across_columns;

	int long_enough;
	int short_enough;
	int contains_original;
	int equal_padding;
	int padded_with_spaces;
};



CenterResultsDatatype testCenterNonTemplate(const double values[TEST_VALUE_COUNT]);
template <typename Datatype>
CenterResultsDatatype testCenterTemplate(const Datatype values[TEST_VALUE_COUNT]);
template <typename Datatype>
void addToResultsBlock(CenterResultsBlock& results,
	const Datatype& value,
	size_t correct_length,
	const string& centered);
void printResultsBlock(const CenterResultsBlock& results);

CenterTotals totalResults(const CenterResultsDatatype& results);
CenterTotals minTotals(const CenterTotals& totals1,
	const CenterTotals& totals2);
CenterTotals maxTotals(const CenterTotals& totals1,
	const CenterTotals& totals2);
int calculateMarkForTotals(const CenterTotals& totals);

bool isEqualPadding(const std::string& str,
	size_t original_starts_at,
	size_t original_length);
bool isPaddedWithSpaces(const std::string& str,
	size_t original_starts_at,
	size_t original_length);
bool isRangeAllSpaces(const std::string& str,
	size_t range_start,
	size_t range_end);



int main()
{
	static const int INT_VALUES[TEST_VALUE_COUNT] =
	{
		1,
		200,
		-34567890,
		40404,
		5
	};

	static const double DOUBLE_VALUES[TEST_VALUE_COUNT] =
	{
		1.0,
		200.0,
		-3.1415926,
		404.04,
		0.5,
	};

	static const string STRING_VALUES[TEST_VALUE_COUNT] =
	{
		"1",
		"GO NUMBER!",
		"pi",
		"404: Webpage not found",
		"0.5 = 1/2",
	};

	testHelperStartup("TestCenter6", COMPILE_AND_START_MARKS, TOTAL_MARKS);
	cout << endl;
	cout << endl;

	//
	//  Test center functions
	//

	cout << "Testing centerDouble function" << endl;
	cout << "=============================" << endl;
	cout << endl;
	CenterResultsDatatype results_nontemplate = testCenterNonTemplate(DOUBLE_VALUES);
	cout << endl;

	cout << "Testing center<int> function" << endl;
	cout << "============================" << endl;
	cout << endl;
	CenterResultsDatatype results_int = testCenterTemplate<int>(INT_VALUES);
	cout << endl;

	cout << "Testing center<double> function" << endl;
	cout << "===============================" << endl;
	cout << endl;
	CenterResultsDatatype results_double = testCenterTemplate<double>(DOUBLE_VALUES);
	cout << endl;

	cout << "Testing center<string> function" << endl;
	cout << "===============================" << endl;
	cout << endl;
	CenterResultsDatatype results_string = testCenterTemplate<string>(STRING_VALUES);
	cout << endl;



	//
	//  Collate results
	//

	CenterTotals totals_nontemplate = totalResults(results_nontemplate);
	CenterTotals totals_int = totalResults(results_int);
	CenterTotals totals_double = totalResults(results_double);
	CenterTotals totals_string = totalResults(results_string);



	//
	//  Print results
	//

	testHelperPrintSummaryHeader(20, 2, DID_NOT_CRASH_RUNNING_MARKS);
	cout << endl;
	cout << "centerDouble" << endl;
	cout << "------------" << endl;
	testHelperPrintSummaryLine("Long enough", totals_nontemplate.long_enough, CHECKS_PER_TEST_TYPE);
	testHelperPrintSummaryLine("Short enough", totals_nontemplate.short_enough, CHECKS_PER_TEST_TYPE);
	testHelperPrintSummaryLine("Contains original", totals_nontemplate.contains_original, CHECKS_PER_TEST_TYPE);
	testHelperPrintSummaryLine("Padding is equal", totals_nontemplate.equal_padding, CHECKS_PER_TEST_TYPE);
	testHelperPrintSummaryLine("Padded with ' 's", totals_nontemplate.padded_with_spaces, CHECKS_PER_TEST_TYPE);
	testHelperPrintSummaryLine("Across full page", totals_nontemplate.across_full_page, CHECKS_PER_BLOCK);
	testHelperPrintSummaryLine("Across box (30)", totals_nontemplate.across_box30, CHECKS_PER_BLOCK);
	testHelperPrintSummaryLine("Across box (5)", totals_nontemplate.across_box5, CHECKS_PER_BLOCK);
	testHelperPrintSummaryLine("Across columns", totals_nontemplate.across_columns, CHECKS_PER_BLOCK);
	cout << endl;
	cout << "center<int>" << endl;
	cout << "-----------" << endl;
	testHelperPrintSummaryLine("Long enough", totals_int.long_enough, CHECKS_PER_TEST_TYPE);
	testHelperPrintSummaryLine("Short enough", totals_int.short_enough, CHECKS_PER_TEST_TYPE);
	testHelperPrintSummaryLine("Contains original", totals_int.contains_original, CHECKS_PER_TEST_TYPE);
	testHelperPrintSummaryLine("Padding is equal", totals_int.equal_padding, CHECKS_PER_TEST_TYPE);
	testHelperPrintSummaryLine("Padded with ' 's", totals_int.padded_with_spaces, CHECKS_PER_TEST_TYPE);
	testHelperPrintSummaryLine("Across full page", totals_int.across_full_page, CHECKS_PER_BLOCK);
	testHelperPrintSummaryLine("Across box (30)", totals_int.across_box30, CHECKS_PER_BLOCK);
	testHelperPrintSummaryLine("Across box (5)", totals_int.across_box5, CHECKS_PER_BLOCK);
	testHelperPrintSummaryLine("Across columns", totals_int.across_columns, CHECKS_PER_BLOCK);
	cout << endl;
	cout << "center<double>" << endl;
	cout << "--------------" << endl;
	testHelperPrintSummaryLine("Long enough", totals_double.long_enough, CHECKS_PER_TEST_TYPE);
	testHelperPrintSummaryLine("Short enough", totals_double.short_enough, CHECKS_PER_TEST_TYPE);
	testHelperPrintSummaryLine("Contains original", totals_double.contains_original, CHECKS_PER_TEST_TYPE);
	testHelperPrintSummaryLine("Padding is equal", totals_double.equal_padding, CHECKS_PER_TEST_TYPE);
	testHelperPrintSummaryLine("Padded with ' 's", totals_double.padded_with_spaces, CHECKS_PER_TEST_TYPE);
	testHelperPrintSummaryLine("Across full page", totals_double.across_full_page, CHECKS_PER_BLOCK);
	testHelperPrintSummaryLine("Across box (30)", totals_double.across_box30, CHECKS_PER_BLOCK);
	testHelperPrintSummaryLine("Across box (5)", totals_double.across_box5, CHECKS_PER_BLOCK);
	testHelperPrintSummaryLine("Across columns", totals_double.across_columns, CHECKS_PER_BLOCK);
	cout << endl;
	cout << "center<string>" << endl;
	cout << "--------------" << endl;
	testHelperPrintSummaryLine("Long enough", totals_string.long_enough, CHECKS_PER_TEST_TYPE);
	testHelperPrintSummaryLine("Short enough", totals_string.short_enough, CHECKS_PER_TEST_TYPE);
	testHelperPrintSummaryLine("Contains original", totals_string.contains_original, CHECKS_PER_TEST_TYPE);
	testHelperPrintSummaryLine("Padding is equal", totals_string.equal_padding, CHECKS_PER_TEST_TYPE);
	testHelperPrintSummaryLine("Padded with ' 's", totals_string.padded_with_spaces, CHECKS_PER_TEST_TYPE);
	testHelperPrintSummaryLine("Across full page", totals_string.across_full_page, CHECKS_PER_BLOCK);
	testHelperPrintSummaryLine("Across box (30)", totals_string.across_box30, CHECKS_PER_BLOCK);
	testHelperPrintSummaryLine("Across box (5)", totals_string.across_box5, CHECKS_PER_BLOCK);
	testHelperPrintSummaryLine("Across columns", totals_string.across_columns, CHECKS_PER_BLOCK);

	unsigned int mark = COMPILE_AND_NOT_CRASH_MARKS;

	CenterTotals totals_min = minTotals(totals_int, minTotals(totals_double, totals_string));
	CenterTotals totals_max = maxTotals(totals_int, maxTotals(totals_double, totals_string));

	mark += calculateMarkForTotals(totals_nontemplate);
	mark += calculateMarkForTotals(totals_min);
	mark += calculateMarkForTotals(totals_max);

	assert(mark <= TOTAL_MARKS);
	testHelperPrintMark(mark, TOTAL_MARKS);

	testHelperWaitForEnter();
	return 0;
}



CenterResultsDatatype testCenterNonTemplate(const double values[])
{
	assert(values != NULL);

	CenterResultsDatatype results;

	cout << "Full page centering:" << endl;
	for (unsigned int i = 0; i < TEST_VALUE_COUNT; i++)
	{
		string centered = centerDouble(values[i]);
		cout << centered << endl;
		addToResultsBlock(results.full_page, values[i], CORRECT_WIDTH_FULL_CENTER, centered);
	}
	printResultsBlock(results.full_page);
	cout << endl;

	cout << "Centered in a box (width 30):" << endl;
	cout << "+------------------------------+" << endl;
	for (unsigned int i = 0; i < TEST_VALUE_COUNT; i++)
	{
		string centered = centerDouble(values[i], 30);
		cout << "|" << centered << "|" << endl;
		addToResultsBlock(results.box30, values[i], 30, centered);
	}
	cout << "+------------------------------+" << endl;
	printResultsBlock(results.box30);
	cout << endl;

	cout << "Centered in a box (width 5):" << endl;
	cout << "+-----+" << endl;
	for (unsigned int i = 0; i < TEST_VALUE_COUNT; i++)
	{
		string centered = centerDouble(values[i], 5);
		cout << "|" << centered << "|" << endl;
		addToResultsBlock(results.box5, values[i], 5, centered);
	}
	cout << "+-----+" << endl;
	printResultsBlock(results.box5);
	cout << endl;

	cout << "Centered in columns (width 10):" << endl;
	cout << "+----------+----------+----------+----------+----------+" << endl;
	for (unsigned int i = 0; i < TEST_VALUE_COUNT; i++)
	{
		string centered = centerDouble(values[i], 10);
		cout << "|" << centered;
		addToResultsBlock(results.columns, values[i], 10, centered);
	}
	cout << "|" << endl;
	cout << "+----------+----------+----------+----------+----------+" << endl;
	printResultsBlock(results.columns);
	cout << endl;

	return results;
}

template <typename Datatype>
CenterResultsDatatype testCenterTemplate(const Datatype values[])
{
	assert(values != NULL);

	CenterResultsDatatype results;

	cout << "Full page centering:" << endl;
	for (unsigned int i = 0; i < TEST_VALUE_COUNT; i++)
	{
		string centered = center(values[i]);
		cout << centered << endl;
		addToResultsBlock(results.full_page, values[i], CORRECT_WIDTH_FULL_CENTER, centered);
	}
	printResultsBlock(results.full_page);
	cout << endl;

	cout << "Centered in a box (width 30):" << endl;
	cout << "+------------------------------+" << endl;
	for (unsigned int i = 0; i < TEST_VALUE_COUNT; i++)
	{
		string centered = center(values[i], 30);
		cout << "|" << centered << "|" << endl;
		addToResultsBlock(results.box30, values[i], 30, centered);
	}
	cout << "+------------------------------+" << endl;
	printResultsBlock(results.box30);
	cout << endl;

	cout << "Centered in a box (width 5):" << endl;
	cout << "+-----+" << endl;
	for (unsigned int i = 0; i < TEST_VALUE_COUNT; i++)
	{
		string centered = center(values[i], 5);
		cout << "|" << centered << "|" << endl;
		addToResultsBlock(results.box5, values[i], 5, centered);
	}
	cout << "+-----+" << endl;
	printResultsBlock(results.box5);
	cout << endl;

	cout << "Centered in columns (width 10):" << endl;
	cout << "+----------+----------+----------+----------+----------+" << endl;
	for (unsigned int i = 0; i < TEST_VALUE_COUNT; i++)
	{
		string centered = center(values[i], 10);
		cout << "|" << centered;
		addToResultsBlock(results.columns, values[i], 10, centered);
	}
	cout << "|" << endl;
	cout << "+----------+----------+----------+----------+----------+" << endl;
	printResultsBlock(results.columns);
	cout << endl;

	return results;
}

template <typename Datatype>
void addToResultsBlock(CenterResultsBlock& results,
	const Datatype& value,
	size_t correct_length,
	const string& centered)
{
	assert(correct_length >= 1);

	if (centered == "")
		return;  // empty string, no marks

	size_t centered_length = centered.length();
	stringstream ss;
	ss << value;
	string original = ss.str();
	size_t original_starts_at = centered.find(original);
	size_t original_length = original.length();

	if (centered_length >= correct_length)
		results.long_enough++;

	if (centered_length <= correct_length)
		results.short_enough++;
	else if (centered == original)
		results.short_enough++;  // OK because started too long

	if (original_starts_at != string::npos)
	{
		results.contains_original++;

		if (isEqualPadding(centered, original_starts_at, original_length))
			results.equal_padding++;
		if (isPaddedWithSpaces(centered, original_starts_at, original_length))
			results.padded_with_spaces++;
	}
}

void printResultsBlock(const CenterResultsBlock& results)
{
	if (results.long_enough < TEST_VALUE_COUNT)
	{
		if (results.long_enough == 0)
			cout << "* Incorrect: Centered strings are always too short" << endl;
		else
			cout << "* Incorrect: Centered strings are sometimes too short" << endl;
	}
	if (results.short_enough < TEST_VALUE_COUNT)
	{
		if (results.short_enough == 0)
			cout << "* Incorrect: Centered strings are always too long" << endl;
		else
			cout << "* Incorrect: Centered strings are sometimes too long" << endl;
	}
	if (results.contains_original < TEST_VALUE_COUNT)
	{
		if (results.contains_original == 0)
			cout << "* Incorrect: Centered strings never contain original string" << endl;
		else
			cout << "* Incorrect: Centered strings sometimes don't contian original" << endl;
	}
	if (results.equal_padding < TEST_VALUE_COUNT)
	{
		if (results.equal_padding == 0)
			cout << "* Incorrect: Centered strings are always padded unequally" << endl;
		else
			cout << "* Incorrect: Centered strings are sometimes padded unequally" << endl;
	}
	if (results.padded_with_spaces < TEST_VALUE_COUNT)
	{
		if (results.padded_with_spaces == 0)
			cout << "* Incorrect: Centered strings are never padded with only spaces" << endl;
		else
			cout << "* Incorrect: Centered strings are not always padded with only spaces" << endl;
	}
	if (results.long_enough == TEST_VALUE_COUNT &&
		results.short_enough == TEST_VALUE_COUNT &&
		results.contains_original == TEST_VALUE_COUNT &&
		results.equal_padding == TEST_VALUE_COUNT &&
		results.padded_with_spaces == TEST_VALUE_COUNT)
	{
		cout << "* Correct" << endl;
	}
}



CenterTotals totalResults(const CenterResultsDatatype& results)
{
	CenterTotals totals;

	totals.across_full_page = results.full_page.getSum();
	totals.across_box30 = results.box30.getSum();
	totals.across_box5 = results.box5.getSum();
	totals.across_columns = results.columns.getSum();

	CenterResultsBlock totals_by_test;
	totals_by_test += results.full_page;
	totals_by_test += results.box30;
	totals_by_test += results.box5;
	totals_by_test += results.columns;

	totals.long_enough = totals_by_test.long_enough;
	totals.short_enough = totals_by_test.short_enough;
	totals.contains_original = totals_by_test.contains_original;
	totals.equal_padding = totals_by_test.equal_padding;
	totals.padded_with_spaces = totals_by_test.padded_with_spaces;

	return totals;
}

CenterTotals minTotals(const CenterTotals& totals1,
	const CenterTotals& totals2)
{
	CenterTotals minimum;

	minimum.across_full_page = (totals1.across_full_page < totals2.across_full_page) ? totals1.across_full_page : totals2.across_full_page;
	minimum.across_box30 = (totals1.across_box30     < totals2.across_box30) ? totals1.across_box30 : totals2.across_box30;
	minimum.across_box5 = (totals1.across_box5      < totals2.across_box5) ? totals1.across_box5 : totals2.across_box5;
	minimum.across_columns = (totals1.across_columns   < totals2.across_columns) ? totals1.across_columns : totals2.across_columns;

	minimum.long_enough = (totals1.long_enough        < totals2.long_enough) ? totals1.long_enough : totals2.long_enough;
	minimum.short_enough = (totals1.short_enough       < totals2.short_enough) ? totals1.short_enough : totals2.short_enough;
	minimum.contains_original = (totals1.contains_original  < totals2.contains_original) ? totals1.contains_original : totals2.contains_original;
	minimum.equal_padding = (totals1.equal_padding      < totals2.equal_padding) ? totals1.equal_padding : totals2.equal_padding;
	minimum.padded_with_spaces = (totals1.padded_with_spaces < totals2.padded_with_spaces) ? totals1.padded_with_spaces : totals2.padded_with_spaces;

	return minimum;
}

CenterTotals maxTotals(const CenterTotals& totals1,
	const CenterTotals& totals2)
{
	CenterTotals maximum;

	maximum.across_full_page = (totals1.across_full_page < totals2.across_full_page) ? totals1.across_full_page : totals2.across_full_page;
	maximum.across_box30 = (totals1.across_box30     < totals2.across_box30) ? totals1.across_box30 : totals2.across_box30;
	maximum.across_box5 = (totals1.across_box5      < totals2.across_box5) ? totals1.across_box5 : totals2.across_box5;
	maximum.across_columns = (totals1.across_columns   < totals2.across_columns) ? totals1.across_columns : totals2.across_columns;

	maximum.long_enough = (totals1.long_enough        < totals2.long_enough) ? totals1.long_enough : totals2.long_enough;
	maximum.short_enough = (totals1.short_enough       < totals2.short_enough) ? totals1.short_enough : totals2.short_enough;
	maximum.contains_original = (totals1.contains_original  < totals2.contains_original) ? totals1.contains_original : totals2.contains_original;
	maximum.equal_padding = (totals1.equal_padding      < totals2.equal_padding) ? totals1.equal_padding : totals2.equal_padding;
	maximum.padded_with_spaces = (totals1.padded_with_spaces < totals2.padded_with_spaces) ? totals1.padded_with_spaces : totals2.padded_with_spaces;

	return maximum;
}

int calculateMarkForTotals(const CenterTotals& totals)
{
	int mark = 0;

	if (totals.long_enough == CHECKS_PER_TEST_TYPE &&
		totals.short_enough == CHECKS_PER_TEST_TYPE)
	{
		mark += 1;
	}
	if (totals.contains_original == CHECKS_PER_TEST_TYPE)
	{
		mark += 1;
	}
	if (totals.equal_padding == CHECKS_PER_TEST_TYPE &&
		totals.padded_with_spaces == CHECKS_PER_TEST_TYPE)
	{
		mark += 1;
	}

	return mark;
}



bool isEqualPadding(const std::string& str,
	size_t original_starts_at,
	size_t original_length)
{
	assert(str != "");

	int original_ends_at = original_starts_at + original_length;

	int left_count = original_starts_at;
	int right_count = str.length() - original_ends_at;
	if (abs(left_count - right_count) <= 1)
		return true;
	else
		return false;
}

bool isPaddedWithSpaces(const std::string& str,
	size_t original_starts_at,
	size_t original_length)
{
	assert(str != "");
	assert(original_starts_at != string::npos);

	// check left padding
	if (!isRangeAllSpaces(str, 0, original_starts_at))
		return false;

	// check right padding
	int original_ends_at = original_starts_at + original_length;
	if (!isRangeAllSpaces(str, original_ends_at, str.size()))
		return false;

	// both paddings are good
	return true;
}

bool isRangeAllSpaces(const std::string& str,
	size_t range_start,
	size_t range_end)
{
	assert(str != "");
	assert(range_start <= range_end);
	assert(range_end <= str.length());

	for (size_t i = range_start; i < range_end; i++)
		if (str[i] != ' ')
			return false;
	return true;
}

