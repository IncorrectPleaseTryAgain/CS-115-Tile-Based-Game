#include <iostream>
#include "TileMoney.h"
#include "Player.h"
#include "Tile.h"

using namespace std;

TileMoney :: TileMoney(unsigned int money1) : Tile()
{
	//set the member variable.
	moneyReceive = money1;
}

TileMoney :: TileMoney(const TileMoney& to_copy) : Tile(to_copy)
{
	//set the member variable.
	moneyReceive = to_copy.moneyReceive;
}

TileMoney :: ~TileMoney()
{
	// It should be empty.
}

TileMoney& TileMoney :: operator= (const TileMoney& to_copy)
{
	if (this != &to_copy)
	{
		moneyReceive = to_copy.moneyReceive;
	}
	return *this;
}

Tile* TileMoney :: getClone() const
{
	Tile* copy = new TileMoney(*this);

	return copy;
}

void TileMoney::activate(unsigned int who_rolled, const CellId& cell, Board& board) const
{
	unsigned int player = getAffectedPlayer(who_rolled);

	playerIncreaseMoneyAndPrint(player, moneyReceive);
}

void TileMoney :: print() const
{
	//call the printOwnerChar function.
	printOwnerChar();

	//print Genus Char
	cout << "$";

	//print Species Char
	cout << moneyReceive;

}