//
//  Tile.cpp
//

#include <cassert>
#include <iostream>

#include "Player.h"
#include "Tile.h"

using namespace std;

const unsigned int NO_OWNER = 999999;



Tile :: Tile ()
{
	owner = NO_OWNER;
}

//new copy constructor
Tile :: Tile(const Tile& to_copy) : owner(to_copy.owner)
{
	owner = to_copy.owner;
}

//virtual destructor
Tile :: ~Tile()
{

}

Tile& Tile :: operator = (const Tile& to_copy)
{
	if (this != &to_copy)
	{
		owner = to_copy.owner;
	}
	return *this;
}

bool Tile :: isOwner () const
{
	//assert(isInvariantTrue());

	if (owner != NO_OWNER)
	{
		return true;
	}
	else
	{
		return false;
	}
}

unsigned int Tile::getAffectedPlayer(unsigned int whose_turn) const
{
	//assert(isInvariantTrue());
	if (owner == NO_OWNER)
	{
		return whose_turn;
	}
	else
	{
		return owner;
	}
}

void Tile :: setOwner (unsigned int owner1)
{
	//assert(isInvariantTrue());

	owner = owner1;

	//assert(isInvariantTrue());
}

void Tile :: printOwnerChar() const
{
	if (owner == NO_OWNER)
	{
		cout << ' ';
	}
	else
	{
		cout << playerGetTileChar(owner);
	}
}


/*

Use ^ copy constructor instead

Tile :: Tile (unsigned int genus1, unsigned int species1)
{
	assert(genus1 < GENUS_COUNT);

	owner   = NO_OWNER;
	genus   = genus1;
	species = species1;

	assert(isInvariantTrue());
}
*/

/*

	//Unwanted private function

unsigned int Tile :: getGenus () const
{
	assert(isInvariantTrue());

	return genus;
}

unsigned int Tile :: getSpecies () const
{
	assert(isInvariantTrue());

	return species;
}

*/

/*
	void Tile :: activate (unsigned int who_rolled, const CellId& rolled_cell, Board& board) const
	{
		//assert(isInvariantTrue());

		unsigned int affected_player = getAffectedPlayer(whose_turn);

		switch(genus)
		{
		case GENUS_MONEY:
			playerIncreaseMoneyAndPrint(affected_player, species);
			break;
		case GENUS_DICE:
			playerIncreaseDiceAndPrint(affected_player, species);
			break;
		case GENUS_POINTS:
			playerIncreasePointsAndPrint(affected_player, species);
			break;
		default:
			cerr << "[Error: Unhandled genus " << genus << " in Tile::activate]";
			break;
		}
	}
*/

/*
void Tile :: print () const
{
	//assert(isInvariantTrue());

	printOwnerChar();
	printGenusChar();
	printSpeciesChar();
}
*/

/*

Private Functions

private:
	void printOwnerChar () const;

	void printGenusChar () const;

	void printSpeciesChar () const;

	bool isInvariantTrue () const;

private:
	unsigned int owner;

	unsigned int genus;

	unsigned int species;


void Tile :: printOwnerChar () const
{
	if(owner == NO_OWNER)
		cout << ' ';
	else
		cout << playerGetTileChar(owner);
}

void Tile :: printGenusChar () const
{
	assert(genus < GENUS_COUNT);
	switch(genus)
	{
	case GENUS_MONEY:
		cout << "$";
		break;
	case GENUS_DICE:
		cout << "#";
		break;
	case GENUS_POINTS:
		cout << "*";
		break;
	default:
		cerr << "[Error: Unhandled genus " << genus << " in Tile::print]";
		break;
	}
}

void Tile :: printSpeciesChar () const
{
	assert(species < 10);  // otherwise more than one char long
	cout << species;
}

bool Tile :: isInvariantTrue () const
{
	if(genus < GENUS_COUNT)
		return true;
	return false;
}
*/

