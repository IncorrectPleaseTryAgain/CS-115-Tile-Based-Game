#include <iostream>
#include "TileMoney.h"
#include "Player.h"
#include "Tile.h"
#include "TileDice.h"

using namespace std;

TileDice::TileDice(unsigned int dice1) : Tile()
{
	//set the member variable.
	diceReceive = dice1;
}

TileDice::TileDice(const TileDice& to_copy) : Tile(to_copy)
{
	//set the member variable.
	diceReceive = to_copy.diceReceive;
}

TileDice :: ~TileDice()
{
	// It should be empty.
}

TileDice& TileDice :: operator= (const TileDice& to_copy)
{
	if (this != &to_copy)
	{
		diceReceive = to_copy.diceReceive;
	}
	return *this;
}

Tile* TileDice :: getClone() const
{
	Tile* copy = new TileDice(*this);

	return copy;
}

void TileDice :: activate(unsigned int who_rolled, const CellId& cell, Board& board) const
{
	unsigned int player = getAffectedPlayer(who_rolled);

	playerIncreaseDiceAndPrint(player, diceReceive);
}

void TileDice :: print() const
{
	//call the printOwnerChar function.
	printOwnerChar();

	//print Genus Char
	cout << "#";

	//print Species Char
	cout << diceReceive;

}