#include <iostream>
#include "Tile.h"
#include "TileBomb.h"
#include "CellId.h"
#include "Board.h"
#include "TileMoney.h"

using namespace std;

TileBomb::TileBomb() : Tile()
{
}

TileBomb::TileBomb(const TileBomb& to_copy) : Tile(to_copy)
{
}

TileBomb :: ~TileBomb()
{
}

TileBomb& TileBomb :: operator = (const TileBomb& to_copy)
{
	if (this != &to_copy)
	{
		TileBomb(to_copy);
	}
	return *this;
}

Tile* TileBomb :: getClone() const
{
	Tile* copy = new TileBomb(*this);

	return copy;
}

void TileBomb :: print() const
{
	cout << " Q "; //endl?
}

void TileBomb :: activate(unsigned int who_rolled, const CellId& cell, Board& board) const
{
//		/ / -> /N/ -> / /-------
//					           |
//    --------------------------
//	  |													/ /==/N/==/ /
//    -> /W/ -> / X / -> /E/-----						/W/==/X/==/E/
//					            |						/ /==/S/==/ /
//    ---------------------------
//	  |
//	  -> / / -> /S/ -> / /		

	//north
	CellId north = cell;

	north.row--;

	if (isOnBoard(north))
	{
		TileMoney money(0);
		board.setAt(north, money, who_rolled);
	}


	//south
	CellId south = cell;

	south.row++;

	if (isOnBoard(south))
	{
		TileMoney money(0);
		board.setAt(south, money, who_rolled);
	}


	//east
	CellId east = cell;

	east.column++;

	if (isOnBoard(east))
	{
		TileMoney money(0);
		board.setAt(east, money, who_rolled);
	}


	//west
	CellId west = cell;

	west.column--;

	if (isOnBoard(west))
	{
		TileMoney money(0);
		board.setAt(west, money, who_rolled);
	}


	//change the board to have an owned TileMoney worth $0 at the position of the cell id passed as a parameter.
	TileMoney money(0);
	board.setAt(cell, money, who_rolled);


	//print the board.
	board.print();
}