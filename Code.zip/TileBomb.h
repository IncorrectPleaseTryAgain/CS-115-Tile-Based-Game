#pragma once
#include "Tile.h"
#include "Board.h"
#include "CellId.h"

class TileBomb : public Tile
{
public:

	TileBomb();

	TileBomb(const TileBomb& to_copy);

	virtual ~TileBomb();

	TileBomb& operator= (const TileBomb& to_copy);

	virtual Tile* getClone() const;

	virtual void activate(unsigned int who_rolled,const CellId& cell,Board& board) const;

	virtual void print() const;
};