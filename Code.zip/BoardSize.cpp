//
//  BoardSize.cpp
//

#include "BoardSize.h"



char getRowName (int row)
{
	return 'A' + row;
}

char getColumnName (int column)
{
	return '0' + column;
}

